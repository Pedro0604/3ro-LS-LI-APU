package ttps.quecomemos.modelo.sugerencia;

public enum TipoSugerencia {
    ALIMENTOS,
    INFRAESTRUCTURA,
    ATENCION,
    OTROS
}
