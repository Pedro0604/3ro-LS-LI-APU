package ttps.quecomemos.modelo.pago;

public enum MetodoPago {
    CREDITO,
    EFECTIVO,
    DEBITO,
    MERCADO_PAGO,
    CUENTA_DNI
}
