package ttps.quecomemos.modelo.menu;

public enum TipoComida {
    ENTRADA,
    PLATO_PRINCIPAL,
    POSTRE,
    BEBIDA,
    OTRO
}