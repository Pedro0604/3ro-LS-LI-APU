package ttps.quecomemos.modelo.usuario;

public enum Turno {
    MAÑANA,
    TARDE
}
