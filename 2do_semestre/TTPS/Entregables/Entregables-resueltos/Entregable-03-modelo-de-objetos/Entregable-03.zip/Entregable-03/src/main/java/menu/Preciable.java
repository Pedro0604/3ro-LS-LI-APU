package menu;

public interface Preciable {
    double getPrecio();
}
