package ttps.quecomemos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuecomemosApplicationTests {

    @Test
    void contextLoads() {
    }

}
