package menu;

public enum MetodoPago {
    CREDITO,
    EFECTIVO,
    DEBITO,
    MERCADO_PAGO,
    CUENTA_DNI
}
