# TTPS - 2024

## Entregable 03

### Modelo de objetos
