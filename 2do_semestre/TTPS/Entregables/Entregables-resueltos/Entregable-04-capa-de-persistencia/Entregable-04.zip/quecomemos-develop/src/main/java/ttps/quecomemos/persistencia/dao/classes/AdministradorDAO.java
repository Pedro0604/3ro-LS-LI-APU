package ttps.quecomemos.persistencia.dao.classes;

import ttps.quecomemos.modelo.usuario.Administrador;

public interface AdministradorDAO extends GenericDAO<Administrador> {
}
