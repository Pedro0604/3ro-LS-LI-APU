package ttps.quecomemos.persistencia.dao.classes;

import ttps.quecomemos.modelo.usuario.ResponsableDeTurno;

public interface ResponsableDeTurnoDAO extends GenericDAO<ResponsableDeTurno> {
}
