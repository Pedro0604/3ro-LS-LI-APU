package sugerencias;

public enum TipoSugerencia {
    ALIMENTOS,
    INFRAESTRUCTURA,
    ATENCION,
    OTROS
}
