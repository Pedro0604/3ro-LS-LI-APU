package usuarios;

public enum Turno {
    MAÑANA,
    TARDE
}
